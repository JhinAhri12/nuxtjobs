const Header_vue_vue_type_style_index_0_scoped_a7bba63a_lang = ".title[data-v-a7bba63a]{color:#22c55d}";

const HeaderStyles_5b5cbd86 = [Header_vue_vue_type_style_index_0_scoped_a7bba63a_lang];

export { HeaderStyles_5b5cbd86 as default };
//# sourceMappingURL=Header-styles.5b5cbd86.mjs.map
