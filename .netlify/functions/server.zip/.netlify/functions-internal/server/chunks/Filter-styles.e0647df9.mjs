const Filter_vue_vue_type_style_index_0_scoped_19da1a12_lang = "button[data-v-19da1a12]{background-color:#0f5e59;color:#fff;padding:10px}input[data-v-19da1a12]{border:1px solid #000;color:#15141a;font-size:.9rem;line-height:1.5;margin:.4rem 0}input[data-v-19da1a12]:focus{border:#0f5e59}";

const FilterStyles_e0647df9 = [Filter_vue_vue_type_style_index_0_scoped_19da1a12_lang];

export { FilterStyles_e0647df9 as default };
//# sourceMappingURL=Filter-styles.e0647df9.mjs.map
