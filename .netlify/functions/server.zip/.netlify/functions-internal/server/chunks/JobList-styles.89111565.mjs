const JobList_vue_vue_type_style_index_0_scoped_c4aff78e_lang = ".job[data-v-c4aff78e]{background-color:#0f5e59;color:#fff;padding:10px}h2[data-v-c4aff78e]{color:#22c55d;font-size:1.5rem;margin-bottom:10px}";

const JobListStyles_89111565 = [JobList_vue_vue_type_style_index_0_scoped_c4aff78e_lang];

export { JobListStyles_89111565 as default };
//# sourceMappingURL=JobList-styles.89111565.mjs.map
