const Signup_vue_vue_type_style_index_0_scoped_7ce4eab5_lang = ".job[data-v-7ce4eab5]{background-color:#0f5e59;color:#fff;margin-top:10px;padding:10px}";

const SignupStyles_c596b808 = [Signup_vue_vue_type_style_index_0_scoped_7ce4eab5_lang];

export { SignupStyles_c596b808 as default };
//# sourceMappingURL=Signup-styles.c596b808.mjs.map
