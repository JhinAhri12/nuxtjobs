const Footer_vue_vue_type_style_index_0_scoped_d8b515b2_lang = "footer[data-v-d8b515b2]{background-color:#0f5e59;color:#fff}";

const FooterStyles_d974657d = [Footer_vue_vue_type_style_index_0_scoped_d8b515b2_lang];

export { FooterStyles_d974657d as default };
//# sourceMappingURL=Footer-styles.d974657d.mjs.map
