const JobDetails_vue_vue_type_style_index_0_scoped_84cb189c_lang = ".job[data-v-84cb189c]{background-color:#0f5e59;color:#fff;padding:10px}";

const JobDetailsStyles_a93b282e = [JobDetails_vue_vue_type_style_index_0_scoped_84cb189c_lang];

export { JobDetailsStyles_a93b282e as default };
//# sourceMappingURL=JobDetails-styles.a93b282e.mjs.map
