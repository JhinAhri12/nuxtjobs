import { b as buildAssetsURL } from './renderer.mjs';

const _imports_0 = "" + buildAssetsURL("job.b42bfb92.jpg");

export { _imports_0 as _ };
//# sourceMappingURL=job-0505b3cb.mjs.map
