const index_vue_vue_type_style_index_0_scoped_f4a793fc_lang = "h1[data-v-f4a793fc]{color:#22c55d;font-size:2rem;margin-bottom:10px}button[data-v-f4a793fc]{background-color:#0f5e59;color:#fff;padding:10px}";

const indexStyles_ae536515 = [index_vue_vue_type_style_index_0_scoped_f4a793fc_lang];

export { indexStyles_ae536515 as default };
//# sourceMappingURL=index-styles.ae536515.mjs.map
