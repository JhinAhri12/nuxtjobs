const _id__vue_vue_type_style_index_0_scoped_45181a59_lang = ".job[data-v-45181a59]{background-color:#0f5e59;color:#fff;padding:10px}";

const _id_Styles_82a40f16 = [_id__vue_vue_type_style_index_0_scoped_45181a59_lang];

export { _id_Styles_82a40f16 as default };
//# sourceMappingURL=_id_-styles.82a40f16.mjs.map
