const profil_vue_vue_type_style_index_0_scoped_aecd3e61_lang = "h2[data-v-aecd3e61],h3[data-v-aecd3e61]{color:#22c55d}";

const profilStyles_a5873bb0 = [profil_vue_vue_type_style_index_0_scoped_aecd3e61_lang];

export { profilStyles_a5873bb0 as default };
//# sourceMappingURL=profil-styles.a5873bb0.mjs.map
