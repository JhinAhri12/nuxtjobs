const BlogPostList_vue_vue_type_style_index_0_scoped_09d74d80_lang = "h3[data-v-09d74d80]{color:#22c55d}";

const BlogPostListStyles_61f8c356 = [BlogPostList_vue_vue_type_style_index_0_scoped_09d74d80_lang];

export { BlogPostListStyles_61f8c356 as default };
//# sourceMappingURL=BlogPostList-styles.61f8c356.mjs.map
