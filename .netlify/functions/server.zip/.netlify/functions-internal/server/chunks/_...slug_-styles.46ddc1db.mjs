const ____slug__vue_vue_type_style_index_0_scoped_73ba624d_lang = ".titleArticle[data-v-73ba624d]{color:#0f5e59}";

const ____slug_Styles_46ddc1db = [____slug__vue_vue_type_style_index_0_scoped_73ba624d_lang];

export { ____slug_Styles_46ddc1db as default };
//# sourceMappingURL=_...slug_-styles.46ddc1db.mjs.map
