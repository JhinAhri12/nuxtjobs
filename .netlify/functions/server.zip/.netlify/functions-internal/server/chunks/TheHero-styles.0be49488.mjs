const TheHero_vue_vue_type_style_index_0_scoped_2767a77b_lang = ".hero-body[data-v-2767a77b]{background-position:50%;background-repeat:no-repeat;background-size:cover;padding-bottom:5px}";

const TheHeroStyles_0be49488 = [TheHero_vue_vue_type_style_index_0_scoped_2767a77b_lang];

export { TheHeroStyles_0be49488 as default };
//# sourceMappingURL=TheHero-styles.0be49488.mjs.map
