// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/blog/default\":[\"content:blog:default.md\"],\"/blog/fetch\":[\"content:blog:fetch.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
