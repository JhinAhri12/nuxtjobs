// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Blog\",\"_path\":\"/blog\",\"children\":[{\"title\":\"Setup Nuxt\",\"_path\":\"/blog/default\"},{\"title\":\"Mémo Fetch\",\"_path\":\"/blog/fetch\"}]}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
